import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1>Hello World123</h1>'
})
export class AppComponent { }
